/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.tarea02_nataliaramirez;

import java.util.ArrayList;

/**
 *
 * @author Natalia Ramirez
 */
public class Main {
    
    public static void main(String[] args) {
        MejoresMetodos f = new MejoresMetodos();
        f.generateInput();
        
//        ArrayList<Long> brute = f.datosBrute();
        
//        ArrayList<Long> dividir = f.datosDividir();
    }
}
