package ec.edu.espol.Main;

import ec.edu.espol.Graph.GraphLA;
import ec.edu.espol.Graph.Vertex;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import org.graalvm.compiler.graph.Graph;

/**
 *
 * @author Jocellyn Luna
 */
public class Main {

    public static void main(String[] args) {

        GraphLA<String, String> grafo = new GraphLA<>(false);

        grafo.addVertex("V1");
        grafo.addVertex("V2");
        grafo.addVertex("V3");
        grafo.addVertex("V4");
        grafo.addVertex("V5");
        grafo.addVertex("V6");

        grafo.connect("V1", "V2", null, 3);
        grafo.connect("V1", "V3", null, 4);
        grafo.connect("V1", "V5", null, 8);
        grafo.connect("V2", "V5", null, 5);
        grafo.connect("V3", "V5", null, 3);
        grafo.connect("V5", "V4", null, 7);
        grafo.connect("V5", "V6", null, 3);
        grafo.connect("V6", "V4", null, 2);

        /*System.out.println(grafo);
        System.out.println("virar grafo:");
        System.out.println(grafo.flipGraphDirections());
        
        LinkedList<LinkedList<Vertex<String,String>>> components = new LinkedList<>();
        grafo.getStronglyConnectedComponents(components);
        System.out.println("Componentes Fuertemente Conexas:\n"+components);*/
        
        System.out.println("dist v1, v6: " + grafo.minDistance("V1", "V6"));
        
    }
//    
   /* public String procesarTexto(String txt){
        String result = "";
        String[] lista = txt.toLowerCase().split(" ");
        
        for(int i = 0; i < txt.length(); i++){
            char current = txt.toLowerCase().charAt(i);
            if(!(",;.:()'!?¿".contains(String.valueOf(current)))){
                result = result + String.valueOf(current);
            }
        }
        return result;
    }
    
    public GraphLA<String, String> generarGrafoSintactico(String txt){
        String procesado = procesarTexto(txt);
        if(procesado != null){
            String[] partes = procesado.split(" ");
            GraphLA<String, String> grafo = new GraphLA(true);
            String previous = "";
            for(int i = 0; i < partes.length; i++){
                grafo.addVertex(partes[i]);
                //metodo que recibe un substring de otro string y retorna las veces que se repite en ese string
                int peso = numRepeticionSubstring(previous+" "+partes[i], txt);
                grafo.connect(previous, partes[i], null, peso);
            }
            return grafo;
        }
        else{
            return null;
        }
        
    }

    private int numRepeticionSubstring(String string, String txt) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public static Map < String, Map < String, List<Student> > > getRegistros (GraphLA<Student, Map<String, String> > grafo) {
        Map<String, Map<String, List<Student>>> mResultado = new HashMap<>();
        LinkedList<Vertex<Studen, Map<String,String>>> vertices = grafo.recorridoAnchura(grafo);
        //recorrer las componentes
        //crear mapa de paralelos para cada materia
        //recorrer arcos de cada vertice
        //verificar que 
    }*/
}

