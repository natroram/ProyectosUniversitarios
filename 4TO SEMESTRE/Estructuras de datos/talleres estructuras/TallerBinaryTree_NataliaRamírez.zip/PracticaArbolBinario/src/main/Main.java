package main;

import tree.BinaryTree;

public class Main {

    public static void main(String[] args) {

        System.out.println("Write your code here...");
        
        BinaryTree<Integer> tree = new BinaryTree(0);
        tree.setLeft(new BinaryTree(1));
        tree.setRight(new BinaryTree(2));
        tree.getLeft().setLeft(new BinaryTree(3));
        tree.getLeft().setRight(new BinaryTree(4));
        tree.getRight().setLeft(new BinaryTree(5));
        tree.getRight().setRight(new BinaryTree(6));
        tree.getRight().getRight().setRight(new BinaryTree(7));
        
        System.out.println("Imprimiento Preorden:");
        tree.printPreordenRecursive();
        
        System.out.println("\nImprimiendo Enorden:");
        tree.printEnordenRecursive();
        
        System.out.println("\nImprimiendo Posorden:");
        tree.printPosordenRecursive();

    }

}
