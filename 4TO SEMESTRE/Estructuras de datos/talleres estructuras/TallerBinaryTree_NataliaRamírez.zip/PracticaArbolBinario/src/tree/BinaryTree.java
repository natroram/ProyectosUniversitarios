package tree;

import java.util.Stack;

public class BinaryTree<T> {

    private BinaryNode<T> root;

    public BinaryTree() {
        this.root = new BinaryNode<>();
    }

    public BinaryTree(T content) {
        this.root = new BinaryNode<>(content);
    }

    public BinaryNode<T> getRoot() {
        return root;
    }

    public void setRoot(BinaryNode<T> root) {
        this.root = root;
    }

    public void setLeft(BinaryTree<T> tree) {
        this.root.setLeft(tree);
    }

    public void setRight(BinaryTree<T> tree) {
        this.root.setRight(tree);
    }

    public BinaryTree<T> getLeft() {
        return this.root.getLeft();
    }

    public BinaryTree<T> getRight() {
        return this.root.getRight();
    }

    public boolean isEmpty() {
        return this.root == null;
    }

    public boolean isLeaf() {
        return this.root.getLeft() == null && this.root.getRight() == null;
    }

    public int countLeavesRecursive() {
        if (this.isEmpty()) {
            return 0;
        } else if (this.isLeaf()) {
            return 1;
        } else {
            int leavesLeft = 0;
            int leavesRight = 0;
            if (this.root.getLeft() != null) {
                leavesLeft = this.root.getLeft().countLeavesRecursive();
            }
            if (this.root.getRight() != null) {
                leavesRight = this.root.getRight().countLeavesRecursive();
            }
            return leavesLeft + leavesRight;
        }
    }

    public int countLeavesIterative() {
        Stack<BinaryTree<T>> stack = new Stack();
        int count = 0;
        if (this.isEmpty()) {
            return count;
        } else {
            stack.push(this);
            while (!stack.empty()) {
                BinaryTree<T> subtree = stack.pop();
                if (subtree.root.getLeft() != null) {
                    stack.push(subtree.root.getLeft());
                }
                if (subtree.root.getRight() != null) {
                    stack.push(subtree.root.getRight());
                }
                if (subtree.isLeaf()) {
                    count++;
                }
            }
        }
        return count;
    }

    public BinaryNode<T> recursiveSearch(T content) {
        if (this.isEmpty()) {
            return null;
        } else {
            if (this.root.getContent().equals(content)) {
                return this.root;
            } else {
                BinaryNode<T> tmp = null;
                if (this.root.getLeft() != null) {
                    tmp = this.root.getLeft().recursiveSearch(content);
                }
                if (tmp == null) {
                    if (this.root.getRight() != null) {
                        return this.root.getRight().recursiveSearch(content);
                    }
                }
                return tmp;
            }
        }
    }
    
    public BinaryNode<T> iterativeSearch(T content){
        Stack<BinaryTree> pila = new Stack<>();
        if(this.isEmpty()){
            return null;
        }
        else{
            pila.push(this);
            BinaryNode<T> nodo = new BinaryNode<>();
            if(!pila.empty()){
                while (!pila.peek().root.getContent().equals(content)) {
                    BinaryTree<T> subtree = pila.pop();
                    if (subtree.root.getLeft() != null ) {
                        nodo = subtree.root.getLeft().root;
                        pila.push(subtree.root.getLeft());
                    }
                    if (subtree.root.getRight() != null) {
                        nodo = subtree.root.getRight().root;
                        pila.push(subtree.root.getRight());
                    }
                
                }
                
            }
            return nodo;
        }
    }
    
    public void printPreordenRecursive(){
        if(this.isEmpty()){
            System.out.println("The tree is empty");
        }
        else{
            System.out.print(this.root.getContent()+" ");
            
            if(this.root.getLeft() != null){
                this.root.getLeft().printPreordenRecursive();
            }
            
            if(this.root.getRight() != null){
                this.root.getRight().printPreordenRecursive();
            }
        }
    }
    
    public void printEnordenRecursive(){
        if(this.isEmpty()){
            System.out.println("The tree is empty");
        }
        else{
            if(this.root.getLeft() != null){
                this.root.getLeft().printEnordenRecursive();
            }
            
            System.out.print(this.root.getContent()+" ");
            
            if(this.root.getRight() != null){
                this.root.getRight().printEnordenRecursive();
            }
        }
    }
    
    public void printPosordenRecursive(){
        if(this.isEmpty()){
            System.out.println("The tree is empty");
        }
        else{
            if(this.root.getLeft() != null){
                this.root.getLeft().printPosordenRecursive();
            }

            if(this.root.getRight() != null){
                this.root.getRight().printPosordenRecursive();
            }
            
            System.out.print(this.root.getContent()+" ");
        }
    }
}
