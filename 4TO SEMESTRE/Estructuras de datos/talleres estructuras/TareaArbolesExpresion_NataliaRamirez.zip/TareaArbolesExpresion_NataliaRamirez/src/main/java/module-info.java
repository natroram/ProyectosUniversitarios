module com.mycompany.tareaarbolesexpresion_nataliaramirez {
    requires javafx.controls;
    exports com.mycompany.tareaarbolesexpresion_nataliaramirez;
}