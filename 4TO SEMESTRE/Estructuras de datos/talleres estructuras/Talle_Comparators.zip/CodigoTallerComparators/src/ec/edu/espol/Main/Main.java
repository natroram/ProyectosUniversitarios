/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ec.edu.espol.Main;

import ec.edu.espol.ArrayList.ArrayList;
import ec.edu.espol.List.List;
import java.util.Iterator;

/**
 *
 * @author ggmendez
 */
public class Main {

    public static void main(String[] args) {

        
        Customer c = new Customer("Ambato", "Old", "Gonzalo Mendez", 25);

        List<Customer> customers = loadCustomers();

        List<Customer> results = customers.findAll((Customer c1, Customer c2) -> {
            if (c1.getCity().equals(c2.getCity())) {
                return 0;
            } else {
                return 1;
            }
        }, c);

        Iterator<Customer> iterator = results.iterator();
        while (iterator.hasNext()) {
            System.out.println(iterator.next());
        }

    }

    public static ArrayList<Customer> loadCustomers() {

        ArrayList<Customer> customers = new ArrayList<>();
        customers.addLast(new Customer("Guayaquil", "New", "Lorena Salinas", 35));
        customers.addLast(new Customer("Guayaquil", "New", "Gabriel Poveda", 25));
        customers.addLast(new Customer("Quito", "New", "Susana Vaca", 29));
        customers.addLast(new Customer("Quito", "New", "Yolanda Martinico", 34));
        customers.addLast(new Customer("Salina", "New", "Alberto Paredes", 27));
        customers.addLast(new Customer("Cuenca", "New", "Janina Figueroa", 30));
        customers.addLast(new Customer("Cuenca", "New", "Ximena Aragundi", 28));
        customers.addLast(new Customer("Ambato", "Old", "Daniel Torres", 29));
        customers.addLast(new Customer("Ambato", "Old", "Rigoberto Martínez", 18));
        customers.addLast(new Customer("Guayaquil", "Old", "Whashington González", 25));
        customers.addLast(new Customer("Guayaquil", "Old", "Luis Muñoz", 22));
        customers.addLast(new Customer("Machala", "Old", "José Haro", 21));
        customers.addLast(new Customer("Machala", "Old", "Luis García", 27));
        customers.addLast(new Customer("Machala", "Old", "Pedro Salazar", 32));
        customers.addLast(new Customer("Quito", "New", "María Fernández", 33));
        customers.addLast(new Customer("Quito", "New", "Josué Hernández", 25));
        customers.addLast(new Customer("Quito", "New", "Fabricio Ontaneda", 21));
        customers.addLast(new Customer("Guayaquil", "Old", "José Márquez", 24));
        customers.addLast(new Customer("Quito", "New", "Verónica Parra", 18));
        customers.addLast(new Customer("Quito", "New", "María Ortiz", 21));
        customers.addLast(new Customer("Guayaquil", "Old", "Jaime Mejía", 24));
        customers.addLast(new Customer("La Libertad", "New", "Aureliano Salazar", 19));
        customers.addLast(new Customer("Santa Elena", "Old", "Claudia Paredes", 20));
        customers.addLast(new Customer("Salinas", "New", "Ignacio Vera", 23));
        customers.addLast(new Customer("Guayaquil", "New", "Manuel Cáceres", 33));
        return customers;

    }

}
