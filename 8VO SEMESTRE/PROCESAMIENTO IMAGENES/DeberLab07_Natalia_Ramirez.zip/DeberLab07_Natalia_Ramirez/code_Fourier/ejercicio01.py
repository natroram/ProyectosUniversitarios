'''''''''''''''''''''''''''''''''''''''''''''
        PROCESAMIENTO DIGITAL DE IMÁGENES

                LABORATORIO 7
       TRANSFORMADA DE FOURIER CON OPENCV
'''''''''''''''''''''''''''''''''''''''''''''

'''
Natalia Ramirez
201911765
Ejercicio 1 - Laboratorio 7
'''

import cv2
import numpy as np
from matplotlib import pyplot as plt


def inputImg():
    img = None
    while (True):
        #ruta = input("\n\tIngrese ruta de la imagen: ")
        ruta = "deber#1_ruido_periodico.jpg"
        img = cv2.imread(ruta, 0)
        if (type(img) != type(None)):
            return img
        else:
            print("\n\tNo se pudo abrir la imagen.\n")

    # return img


while (True):
    print("\n\n************************************************************")
    print("\n\t\tPROCESAMIENTO DIGITAL DE IMÁGENES")
    print("\n\t\t    TRANSFORMADA DE FOURIER")
    print("\n\n************************************************************")

    img = inputImg()  # carga imagen de entrada
    cv2.imshow("Img", img)
    cv2.waitKey(0)

    img_float32 = np.float32(img)  # mapea imagen de entrada a 32 bits/pixel

    dft = cv2.dft(img_float32, flags=cv2.DFT_COMPLEX_OUTPUT)  # calcula la transf. Fourier
    dft_shift = np.fft.fftshift(dft)  # proyecta los cuadrantes de la imagen

    magnitude_spectrum = 20 * np.log(cv2.magnitude(dft_shift[:, :, 0], dft_shift[:, :,
                                                                       1]))  # encuentra la magnitud, usa mapeo logaritmico y absoluto de la imagen real e imaginaria

    row, col = img.shape
    crow = int(row / 2)

    mask = np.ones((row, col, 2), np.uint8)
    mask[:, crow-12:crow-8] = 0
    mask[:, crow+74:crow+79] = 0
    print(mask)

    apply_mask = dft_shift * mask
    magnitude_spectrum2 = 20 * np.log(cv2.magnitude(apply_mask[:, :, 0], apply_mask[:, :, 1]))

    invertida = np.fft.ifftshift(apply_mask)

    img_salida = cv2.idft(invertida)
    img_salida = cv2.magnitude(img_salida[:, :, 0], img_salida[:, :, 1])

    plt.subplot(121), plt.imshow(img, cmap='gray')
    plt.title('Input Image'), plt.xticks([]), plt.yticks([])
    plt.subplot(122), plt.imshow(img_salida, cmap='gray')
    plt.title('Imagen Corregida'), plt.xticks([]), plt.yticks([])
    plt.show()
