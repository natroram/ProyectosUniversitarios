from django.db.models import Count, Min
from django.http import JsonResponse
from django.shortcuts import render
from django.views.generic import ListView
from .forms import VideoForm
from .models import Video, Interpolation
from .utils import change_res

L = ['mp4', 'avi', 'wmv']
extensions = ['mp4v', 'XVID', 'WMV2']


def upload_video(request):
    if request.method == 'POST':
        l = int(request.POST['select'])
        datos = L[l - 1], extensions[l - 1]
        print(datos)
        form = VideoForm(request.POST, request.FILES)
        if form.is_valid():
            my_model_instance = form.save(commit=False)
            name, ext = str(my_model_instance.file).split('.')
            my_model_instance.title = f'{name}-original'
            my_model_instance.save()
            change_res(my_model_instance, datos)
            return JsonResponse({'success': True})
    else:
        form = VideoForm()
    return render(request, 'form.html', {'form': form})


class VideoListView(ListView):
    template_name = 'list.html'
    model = Video

    def get_interpolation(self, pk):
        n = Interpolation.objects.filter(video_id=pk)
        return n

    def best(self, pk):
        n = Interpolation.objects.filter(video_id=pk).order_by('error')
        record = n[0]
        record.best = True
        record.save()

    def get_queryset(self):
        qs = self.model.objects.all()
        d = {}
        for i in qs:
            d[i] = self.get_interpolation(i.pk).order_by('error')
            self.best(i.pk)
        return d

    def get_context_data(self, *, object_list=None, **kwargs):
        context = super().get_context_data(**kwargs)
        context['qs'] = self.get_queryset()
        return context
