import os

import cv2
from django.conf import settings
from django.core.files.base import File

from interpolation.models import Interpolation


def change_res(video, tipo):
    video_path = f'{settings.MEDIA_ROOT}/{str(video.file)}'
    n = detect_faces(video)
    video.count = n
    video.save()
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        print("The video could not be opened.")
        return
    fps = int(cap.get(cv2.CAP_PROP_FPS))
    old_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    old_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    lr_width, lr_height = old_width // 4, old_height // 4
    lr_width, lr_height = int(lr_width), int(lr_height)
    l = tipo[1]
    fourcc = cv2.VideoWriter_fourcc(*l)
    out = cv2.VideoWriter(f'lr.{tipo[0]}', fourcc, fps, (lr_width, lr_height))
    while cap.isOpened():
        ret, frame = cap.read()
        if ret:
            lr_frame = cv2.resize(frame, (lr_width, lr_height))
            out.write(lr_frame)
        else:
            break
    cap.release()
    out.release()
    cv2.destroyAllWindows()
    create_interpolation(video, f'lr.{tipo[0]}', 'Baja_resolucion')
    l = ['bilineal', "area", "nearest", "bicubica", "lanczos"]
    for j in l:
        interpolation(video, f'{j}.{tipo[0]}', j, tipo)
    import os
    import glob
    extension = f"*.{tipo[0]}"
    files = glob.glob(extension)
    for file in files:
        os.remove(file)


def create_interpolation(video, name, tecnica):
    with open(name, "rb") as f:
        video_new = Interpolation(file=File(f), video_id=video.pk, technique=tecnica,
                                  name=str(video.file).split('.')[0] + tecnica)
        video_new.save()
    total = video.count
    n = detect_faces(video_new)
    dif = total - n
    video_new.count = n
    video_new.error = float((dif * 100) / total)
    video_new.save()


def interpolation(new_video, name, technique, tipo):
    video = cv2.VideoCapture(f'lr.{tipo[0]}')
    fps = int(video.get(cv2.CAP_PROP_FPS))
    width = int(video.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(video.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fourcc = cv2.VideoWriter_fourcc(*f"{tipo[1]}")
    new_w, new_h = 4 * width, 4 * height
    interpolacion = cv2.VideoWriter(f"{technique}.{tipo[0]}", fourcc, fps, (new_w, new_h))
    frame1 = ''
    while True:
        ret, frame = video.read()
        if not ret:
            break
        if technique == "bilineal":
            frame1 = cv2.resize(frame, (new_w, new_h), interpolation=cv2.INTER_LINEAR)
        elif technique == "area":
            frame1 = cv2.resize(frame, (new_w, new_h), interpolation=cv2.INTER_AREA)
        elif technique == "nearest":
            frame1 = cv2.resize(frame, (new_w, new_h), interpolation=cv2.INTER_NEAREST)
        elif technique == "bicubica":
            frame1 = cv2.resize(frame, (new_w, new_h), interpolation=cv2.INTER_CUBIC)
        elif technique == "lanczos":
            frame1 = cv2.resize(frame, (new_w, new_h), interpolation=cv2.INTER_LANCZOS4)
        interpolacion.write(frame1)
    video.release()
    interpolacion.release()
    create_interpolation(new_video, name, technique)


def detect_faces(video):
    video_path = f'{settings.MEDIA_ROOT}/{str(video.file)}'
    video_capture = cv2.VideoCapture(video_path)
    face_cascade = cv2.CascadeClassifier("haarcascade_frontalface_default.xml")
    face_count = 0
    if not video_capture.isOpened():
        print("The video could not be opened.")
        return
    while video_capture.isOpened():
        ret, frame = video_capture.read()
        if not ret:
            break
        frame = cv2.flip(frame, 1)
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = face_cascade.detectMultiScale(gray, 1.3, 5)
        face_count += len(faces)
    video_capture.release()
    return face_count
