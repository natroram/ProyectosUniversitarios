from django.urls import path
from .views import *

urlpatterns = [
    path('upload/', upload_video, name='upload_video'),
    path('list/', VideoListView.as_view(), name='count'),
]
