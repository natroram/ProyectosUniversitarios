from django.contrib import admin

from interpolation.models import Video, Interpolation


# Register your models here.
@admin.register(Video)
class VideoAdmin(admin.ModelAdmin):
    list_display = ('file', 'title', 'count')


@admin.register(Interpolation)
class InterpolationAdmin(admin.ModelAdmin):
    list_display = ('file', 'name', 'technique', 'video', 'count', 'error', 'best')
