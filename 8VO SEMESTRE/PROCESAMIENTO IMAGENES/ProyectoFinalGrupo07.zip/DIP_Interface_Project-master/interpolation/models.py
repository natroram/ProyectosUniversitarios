from django.db import models


# Create your models here.

class Video(models.Model):
    title = models.CharField(max_length=255)
    file = models.FileField(upload_to='videos/')
    count = models.IntegerField(null=True, default=0)

    def __str__(self):
        return f"{self.pk}"


class Interpolation(models.Model):
    video = models.ForeignKey(Video, on_delete=models.CASCADE)
    technique = models.CharField(max_length=255)
    file = models.FileField(upload_to='interpolation/')
    name = models.CharField(max_length=255)
    count = models.IntegerField(null=True, default=0)
    error = models.DecimalField(null=True, default=0, decimal_places=2, max_digits=6)
    best = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.video.title}"
