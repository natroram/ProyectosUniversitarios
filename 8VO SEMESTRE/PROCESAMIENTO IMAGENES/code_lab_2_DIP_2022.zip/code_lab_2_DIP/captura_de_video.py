'''
             PROCESAMIENTO DIGITAL DE IMÁGENES
             ---------------------------------

               Como capturar video en OpenCv
    Captura de video desde una cámara o un archivo de video


El presente laboratorio tiene como objetivo aprender a adquirir datos de entrada en forma
de imágenes o videos para su posterior visualización o representación en diferentes formatos
de imágenes. Para esto, primero se aprenderá a capturar los datos de entrada en forma de
video desde una webcam o cámara de adquisicion (se ofrece tambien como alternativa cargar un
archivo de video como dato de entrada). Luego, se da a conocer las funciones de conversión
o representacion de una imagen RGB a una imagen a Escala de Grises o a una imagen Binaria,
finalmente, estas imagenes son visualizadas en sus respectivas representaciones.
'''

import cv2     #llama a OpenCv


#Captura de video desde archivo
capture = cv2.VideoCapture("video1.avi")

#Captura de video desde cámara
#capture = cv2.VideoCapture(0)


#Visualización de la señal de video en sus diferentes representaciones de imágenes 
cv2.namedWindow("Video: --> Original - representacion Color", cv2.WINDOW_AUTOSIZE)
#Ventanas adicionales
cv2.namedWindow("Video: --> representacion Escala de Grises", cv2.WINDOW_AUTOSIZE)
cv2.namedWindow("Video: --> representacion Binaria", cv2.WINDOW_AUTOSIZE)

while(True):

    #Lectura de los frames desde la señal de video (cámara o archivo de video)
    ret, frame = capture.read()
    #Si llega al final del video no habrá frames
    if(not ret):
      break

    #Convertir la señal de video a escala de grises
    frameGris = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    #Convertir la señal de video a binaria
    ret, frameBin = cv2.threshold(frameGris, 80, 255, cv2.THRESH_BINARY)

    #Muestra el video resultante en sus diferentes representaciones de imágenes
    cv2.imshow("Video: --> Original - representacion Color",frame)
    cv2.imshow("Video: --> representacion Escala de Grises",frameGris)
    cv2.imshow("Video: --> representacion Binaria",frameBin)

    key = cv2.waitKey(33) #Retraso en milisegundos para leer el siguiente frame (nota para archivo de imagen poner 0 )
    #Termina presionando la tecla Esc
    if (key==27):
        break

cv2.waitKey(0)
cv2.destroyAllWindows()

capture.release()
