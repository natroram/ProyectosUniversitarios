#include <stdio.h>
#include <stdlib.h>

void main()
{

printf("Hola mundo");

}
