/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * main.c
 * Copyright (C) Daniel Ochoa Donoso 2011 <dochoa@fiec.espol.edu.ec>
 * 
 * main.c is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * main.c is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include <math.h> 
#include <stdio.h>
#include <errno.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <unistd.h>
#include <stdlib.h>
 
#define SHMSZ     4 //tamaño de entero
#define NUM_SONS	5 //numero de procesos hijos

int main(int argc, char *argv[])
{
	pid_t pid;
    int shmid,total,i,status,j,k;
    key_t key;
	int *shm;
	key = 1678;


	if (argc != 2) {
		fprintf(stderr,"usage: a.out <integer value>\n");	
		abort();
	}

	if (atoi(argv[1]) < 0) {
		fprintf(stderr,"Argument %d must be non-negative\n",atoi(argv[1]));	
		abort();
	}
    // uso segmento de memoria compartida para compartir datos
    if ((shmid = shmget(key, SHMSZ, IPC_CREAT | 0666)) < 0) {
    	    perror("shmget");
        	abort();
	}
   if ((shm = (int *)shmat(shmid, NULL, 0)) == (int *) -1) {
	        	perror("shmat");
	        	abort();
		    }
	*shm=0;
//	sleep(1);
	for (k=0;k<NUM_SONS;k++)
	{
		pid=fork();	
		if (pid==0) //codigo del hijo
		{
			shmid=0;shm=NULL;
			if ((shmid = shmget(key, SHMSZ, 0666)) < 0) {
     	   		perror("shmget");
        		abort();;
    		}
	    	if ((shm = (int *)shmat(shmid, NULL, 0)) == (int *) -1) {
    	    	perror("shmat");
    	    	abort();;
    		}
			for (i=0;i<atoi(argv[1]);i++)
			{
				total=*shm;
				total++;	
				j=(int)(100.0*rand()/RAND_MAX);
				usleep(j);		
				(*shm)=total;
				
			}			
			exit(EXIT_SUCCESS);
		}
	}
	
	while (1) {
	    pid_t done = wait(&status);
	    if (done == -1) {
        if (errno == ECHILD) break; // no more child processes
	    } else {
        if (!WIFEXITED(status) || WEXITSTATUS(status) != 0) {
            printf("hijo %d terminado\n",done);
    	    }
    	}
	}

	printf("padre total= %d\n",*shm);

	exit(EXIT_SUCCESS);
}
