# LENGUAJES DE PROGRAMACIÓN
## TALLER ANALIZADOR LÉXICO

Para desarrollar el taller siga las recomendaciones:
1. Identifique cada uno de los componentes léxicos que ha definido en su propuesta. No es necesario que incluya todos.
2. Utilice la base en python que se le provee.
3. Cada vez que haya definido un token revise si es reconocido como tal.

Recuerde que, este taller es **individual** y para obtener una calificación completa, debe definir al menos los siguientes componentes:

```
1. Escritura de variables
2. Operadores aritméticos
3. Operadores de comparación
4. Conectores lógicos
5. Palabras reservadas: estructuras de control, tipado (cast), funciones
6. Caracteres Especiales: separadores, carácter de fin de línea, carácter de bloque de sentencias
```
Finalmente, utilice un algoritmo de prueba en su LP (source.extension) asignado donde se puedan comprobar todos los tokens. Para entregar su taller haga click en **Submit** antes de las 13h00.


Nota: Recuerde que puede preguntar al profesor cualquier duda durante el taller. No espere hasta el final.

Muchos éxitos :)