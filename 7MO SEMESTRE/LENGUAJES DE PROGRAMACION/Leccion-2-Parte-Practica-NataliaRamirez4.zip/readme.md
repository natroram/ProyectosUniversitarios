# LENGUAJES DE PROGRAMACIÓN P1
## LECCIÓN 2

## Indicaciones
Para la parte práctica en PLY siga las instrucciones:
1. **Copie los queries** del ejercicio de BNF (Aula Virtual) **en el archivo queries.sql**
2. Agregue solo los componentes léxicos que ha identificado en sus queries. **No agregue tokens que no va a utilizar.**
3. Agregue las reglas sintácticas para sus queries. Y **solo las reglas que necesita** para validar sus ejemplos.
4. Compruebe que su analizador está completo antes de enviar. Debe hacer build y **devolver los tokens reconocidos** y **si hay o no error de sintaxis** en alguno de los 3 ejemplos.
5. Use la base de proyecto (main.py) que se le provee y a medida que vaya agregando componentes y reglas compruébelas. **No cree más archivos python ni renombre los mismos.**
   
NOTA: Solo se aceptarán envíos (Submit) hasta las 13h00. Los cambios posteriores no entran a evaluación.