select * from company

select id, name from table where id=3 or id=6

select top 1 * from empleado where sales>999.99 and city="GYE"
