# Lenguajes de Programación
## Challenge PHP

Dada una lista de tiempos diferentes y nombres de los participantes en Iron Runner Gye 2021,  encontrar el nombre del participante que ha clasificado en tal lugar (posición específica). Para ello deberá implementar una función ranking(tiempos, participantes, posicion) que retorne el nombre del participante en esa posición.  

Tenga en cuenta que si el tiempo es menor se refiere a que está en los primeros lugares, y si el tiempo es mayor que está en los últimos lugares.

En caso de que la posición no exista (se supera), deberá controlar que siga funcionando su programa y retornará por defecto quien tenga el peor tiempo. 

Ejemplo
```
tiempos = [13.2, 10.8, 12.9, 10.1, 13.7, 10.2]
participantes = ['Rodrigo', 'Carlos', 'Ana', 'Luis', 'Pedro', 'Cristina']

ranking(tiempos, participantes, 2)
Salida: Cristina

ranking(tiempos, participantes, 1)
Salida: Luis

ranking(tiempos, participantes, 10) #no existe, entonces retorna quien tenga peor tiempo
Salida: Pedro
```