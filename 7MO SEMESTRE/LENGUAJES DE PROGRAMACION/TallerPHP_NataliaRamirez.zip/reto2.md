# Lenguajes de Programación
## Challenge PHP

Crear un formulario que simule el servicio de Google Translate para escribir palabras u frases en 4 idiomas, envíe cada palabra o frase y presente los resultados de la traducción.

Para ello deberá crear un archivo php con la función translate(origen, destino, palabras) que recibe idioma original, idioma destino, y 1 o varias palabras. Retorna una cadena con la traduccion.

Como base dispone el archivo diccionario.csv para realizar la consulta de palabras y traducción. Existen 4 lenguajes actualmente: español, inglés, portugues, italiano.