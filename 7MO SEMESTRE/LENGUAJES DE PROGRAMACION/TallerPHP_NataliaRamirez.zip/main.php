<?php
require("users.php");

$cedula = $_POST["cedula"];
$password = $_POST["clave"];

if(access($cedula, $password)){
  session_start();

    if(isset($_POST["logout"])){
      header("Location: https://PracticaPHPIntermedio-NataliaRamirez4.lp2022p1.repl.co/login.php");
      #session_destroy();
    }

    echo "
      <h3>Inicio de sesión exitoso</h3>
      <h2>Bienvenido $cedula</h2>
       <form method=\"post\">
            <input type=\"submit\" name=\"logout\"
                    value=\"Cerrar Sesión\"/>
       </form>
      ";
}
?>
<html>
  <head>
    <title>Bienvenido</title>
  </head>
</html>