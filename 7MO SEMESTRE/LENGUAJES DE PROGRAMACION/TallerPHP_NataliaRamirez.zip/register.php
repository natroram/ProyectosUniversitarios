<html>
  <head>
    <title>Registro Usuario</title>
  </head>
  <body>
    <h2>Registrarse</h2>
<form action="welcome.php" method="post">
    <p>
    <label for="cedula">Cedula: </label>
              <input type="number" id="cedula" name= "cedula" max=9999999999></label><br>
    <label for="nombre">Nombre: </label>
              <input type="text" id="nombre" name= "nombre"><br>
    <input type="radio" name="sexo" value="masculino"> Masculino<br>
    <input type="radio" name="sexo" value="femenino"> Femenino<br>
    <input type="radio" name="sexo" value="Otro"> Otro<br>
    <label for="email">Email: </label>
              <input type="email" id="email" name= "correo" required><br>
  <label for="contrasena">Contraseña: </label>
              <input type="password" id="contrasena"name= "clave"><br>
    
    <input type="submit" value="Registrar"> <input type="reset">
    </p>
 </form>

</body>
  <script src="https://replit.com/public/js/replit-badge.js" theme="blue" defer></script> 
</html>