<?php 
$nombre = $_POST["nombre"];
if(!isset($nombre)){
  echo "Campo nombre vacio";
}else{
  echo "Nombre: $nombre";
}

?>