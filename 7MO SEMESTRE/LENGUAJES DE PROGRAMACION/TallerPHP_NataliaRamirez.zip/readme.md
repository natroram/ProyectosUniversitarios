# Lenguajes de Programación
## Taller PHP

1.	El primer ejercicio será crear un formulario de registro en el archivo register.php, este formulario debe solicitar lo siguiente:
* cedula como caja de texto de tipo numérico 10 digitos
* nombre como caja de texto
* genero como selección Masculino, Femenino, Otro
* correo electrónico como caja de texto tipo email (valide)
* contrasenia como caja de texto tipo password
* No olvide el botón Registrar

2.	Enviar los datos al archivo welcome.php que recibe todos los datos, los imprime en una tabla html. La contraseña imprimirla cifrada usando md5. Adicionalmente, en la cabecera imprime el mensaje Bienvenido $sunombre 🤩 (defina un array con al menos 5 emojis favoritos para que en cada test aparezca uno distinto: https://www.w3schools.com/html/html_emojis.asp).

3.	Adicionalmente, cree un archivo users.php que también es requerido en welcome.php y usa la función save($array) para almacenar los datos en una línea del archivo users.csv.

4.	En el mismo archivo users.php cree otra función validate($cedula) que devuelve True si ya existe ese registro en users.csv o False en caso de que no exista. También cree otra función access($cedula, $password) que valida si existe esta cédula y su contraseña.

5.	Aplique esta validación antes de hacer un nuevo registro de usuario en register.php; en caso de que ya exista el usuario redireccionelo al archivo login.php

6. Ingrese sus datos en login.php y envíe sus datos al archivo main.php, valide usando la función access de users.php, cree una sesión e imprima que ha iniciado sesión su nombre de usuario. Agregue un boton para cerrar sesión y que lo redireccione al archivo login.php
