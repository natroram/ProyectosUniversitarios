<?php
require("users.php");

$emojis = ["&#128512;", "&#128513;", "&#128514;", "&#128516;", "&#128517;"];
$emoji = $emojis[rand(0,4)];
$cedula = $_POST["cedula"];
$nombre = $_POST["nombre"];
$genero = $_POST["sexo"];
$email = $_POST["correo"];
$contrasena = md5($_POST["clave"]);

$campos = [$cedula, $nombre, $genero, $email, $contrasena];

$validar = validate($cedula);

if ($validar) {
  header("Location: https://PracticaPHPIntermedio-NataliaRamirez4.lp2022p1.repl.co/login.php");
}else{
  save($campos);
}

echo "<h3>Bienvenido $nombre $emoji</h3>";
echo "<table>
  <tr>
    <th>Cedula</th>
    <th>Nombre</th>
    <th>Genero</th>
    <th>Email</th>
    <th>Contraseña</th>
  </tr>
  <tr>
    <td>$cedula</td>
    <td>$nombre</td>
    <td>$genero</td>
    <td>$email</td>
    <td>$contrasena</td>
  </tr>

</table>";
?>
<html>
  <head>
    <title>Bienvenido</title>
  </head>
</html>