<?php
function save($array){
  $registro = implode(",", $array);
  $file = fopen("users.csv", "a") or die("Error al abrir el archivo");
  fwrite($file, $registro);
  fclose($file);
}

function validate($cedula){
  $file = fopen("users.csv", "r") or die("Error al abrir el archivo");
  while(!feof($file)) {
    $line = explode(",", fgets($file));
    if ($cedula == $line[0]){
      fclose($file);
      return true;
    }
    else{
      fclose($file);
      return false;
    }
  }
}

function access($cedula, $password){
  $file = fopen("users.csv", "r") or die("Error al abrir el archivo");
  while(!feof($file)) {
    $line = explode(",", fgets($file));
    if (($cedula == $line[0]) and (md5($password)) == $line[4]){
      fclose($file);
      return true;
    }
    else{
      fclose($file);
      return false;
    }
  }
}
?>