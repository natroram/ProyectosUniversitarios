<html>
  <head>
    <title>Iniciar Sesion</title>
  </head>
  <body>
    <h2>Iniciar Sesión</h2>
<form action="main.php" method="post">
    <p>
    <label for="cedula">Cedula: </label>
              <input type="number" id="cedula" name= "cedula" max=9999999999></label><br>
  <label for="contrasena">Contraseña: </label>
              <input type="password" id="contrasena"name= "clave"><br>
    
    <input type="submit" value="Login"> <input type="reset">
    </p>
 </form>

</body>
  <script src="https://replit.com/public/js/replit-badge.js" theme="blue" defer></script> 
</html>