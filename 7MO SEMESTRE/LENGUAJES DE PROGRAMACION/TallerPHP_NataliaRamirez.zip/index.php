<?
session_start();
   
   if( isset( $_SESSION['contador'] ) ) {
      $_SESSION['contador'] += 1;
   }else {
      $_SESSION['contador'] = 1;
   }
	
   $msg = " Visita nro ".  $_SESSION['contador'];
   $msg .= " en esta sesión.";

header("Location: https://PracticaPHPIntermedio-NataliaRamirez4.lp2022p1.repl.co/register.php")
?>

<html>
  <head>
    <title>PHP Test</title>
  </head>
  <body>
    <a href= "register.php">Registro</a>
<?php # echo '<p>Taller 2</p>'; 

/*10 cosas de php
//1. Escritura de variables
$_ = "Hola mundo<br>";
echo $_;
  
//2. Concatenación de strings

$msj = $_."Buenos días<br>";
print($msj);

//3. Nuevos tipos de datos: resource
$fp = fopen("file.txt", "w");
echo get_resource_type($fp) . "\n";
  
//4. Estructuras de control
$arr = array(1, 2, 3, 4);
foreach ($arr as $value) {
    $value = $value * 2;
}
// $arr is now array(2, 4, 6, 8)
unset($value);

//5. Estructuras de datos

$array = array(
    "foo" => "bar",
    "bar" => "foo",
);
var_dump($array);

//6. Métodos de encriptación

echo md5(123)."<br>";
//echo password_hash("123", PASSWORD_DEFAULT)."<br>";
//echo password_hash("123", PASSWORD_BCRYPT);

//7. Requerir o incluir otros recursos

//require("main.php");
//include("main.php");
*/
//8. Posibilidad de escribir html
 ?>
    
<?php

//9. Manejo de sesiones
//Revise en la parte superior el ejemplo
#echo $msg;

# unset($_SESSION['contador']);
# session_destroy();

//10. Archivos

$archivo = "file.txt";
$recurso = fopen($archivo, "r" );
if($recurso == false ) {
  echo ( "Error al abrir archivo" );
  exit();
}
         
$tamano = filesize($archivo);
$texto = fread($recurso, $tamano);
fclose($recurso);
         
#echo ( "<br>Peso:<pre> $tamano bytes</pre>" );
#echo ( "<br>Texto:<pre>$texto</pre>" );
   ?> 
    <script src="https://replit.com/public/js/replit-badge.js" theme="blue" defer></script> 
  </body>
</html>